#include "../include/slice_types.h"
#include "../include/logic.h"

/*@ Import Coq Require Import CRTOS_Verify.VC.LinklistResumeAll_lib */
/*@ Extern Coq
  (semaphore_resume_all_steps : addr -> list addr -> VarGlobalState -> VarGlobalState -> Prop)
  (set_task_desc_exstatus : TaskDescriptorAbs -> Z -> TaskDescriptorAbs)
  (resume_next_restore : StableGlobalState -> VarGlobalState -> addr -> addr -> Assertion)
  (resume_exstatus_restore : StableGlobalState -> VarGlobalState -> Z -> Z -> Assertion)
  (resume_id_restore : StableGlobalState -> VarGlobalState -> Z -> Z -> Assertion)
 */

/* Source: /home/xinra/crtos/Ubiquitous/XiZi_IIoT_Macro/kernel/thread/linklist.c. Current 32-bit non-SMP configuration. */
struct TaskDescriptor *CONTAINER_OF_TASK_SCHED(DoubleLinklistType *sched_link_ptr)
/*@ With task_ptr
    Require addr_aligned(task_ptr, ALIGN_SIZE) &&
            sched_link_ptr == sched_link_of(task_ptr) &&
            emp
    Ensure __return == task_ptr &&
           addr_aligned(__return, ALIGN_SIZE) &&
           sched_link_ptr ==
             &(__return->task_dync_sched_member.sched_link)
 */;

x_err_t KTaskWakeup(int32 id)
/*@ wakeup_by_id_ic
    With (sg : StableGlobalState) (before : VarGlobalState)
    Require id < 65536 && os_inv(sg, before)
    Ensure exists (task : Z) (desc : TaskDescriptorAbs) (after : VarGlobalState),
      task != 0 && get_task_with_idnode_success(sg, before, id, task) &&
      before.os_tasks.task_desc_map(task) == Some(desc) &&
      ((desc.tdSchedMember.tsmStat != TSK_SUSPEND && __return == -1 && after == before)
       ||
       (desc.tdSchedMember.tsmStat == TSK_SUSPEND && __return == 0 &&
        ktask_wakeup_step(task, desc, before, after))) && os_inv(sg, after)
 */
/*@ detached_sched_null_delay <= wakeup_by_id_ic
    With (sg : StableGlobalState) (before : VarGlobalState)
    Require id < 65536 && ktask_wakeup_detached_null_condition(sg, before, id) &&
      os_inv(sg, before)
    Ensure exists (task : Z) (desc : TaskDescriptorAbs) (after : VarGlobalState),
      task != 0 && get_task_with_idnode_success(sg, before, id, task) &&
      before.os_tasks.task_desc_map(task) == Some(desc) && desc.tdDelay == 0 &&
      ((desc.tdSchedMember.tsmStat != TSK_SUSPEND && __return == -1 && after == before)
       ||
       (desc.tdSchedMember.tsmStat == TSK_SUSPEND && __return == 0 &&
          ktask_wakeup_detached_null_step(task, desc, before, after))) &&
      os_inv(sg, after)
 */
/*@ semaphore_pending_head_ic <= wakeup_by_id_ic
    With (sg : StableGlobalState) (before : VarGlobalState)
      (sem task : Z) (rest : list(DL_Node Z))
    Require id < 65536 && get_task_with_idnode_success(sg, before, id, task) &&
      semaphore_pending_nodes(sem, before, cons(sched_link_node(task), rest)) &&
      os_inv(sg, before)
    Ensure exists (desc : TaskDescriptorAbs) (after : VarGlobalState),
      __return == 0 && task != 0 &&
      before.os_tasks.task_desc_map(task) == Some(desc) &&
      desc.tdSchedMember.tsmStat == TSK_SUSPEND &&
      wakeup_semaphore_head(sem, task, desc, before, after) &&
      semaphore_pending_nodes(sem, after, rest) && os_inv(sg, after)
 */
/*@ msgqueue_send_pending_head_ic <= wakeup_by_id_ic
    With (sg : StableGlobalState) (before : VarGlobalState)
      (mq task : Z) (rest : list(DL_Node Z))
    Require id < 65536 && get_task_with_idnode_success(sg, before, id, task) &&
      msgqueue_send_pending_nodes(mq, before, cons(sched_link_node(task), rest)) &&
      os_inv(sg, before)
    Ensure exists (desc : TaskDescriptorAbs) (after : VarGlobalState),
      __return == 0 && task != 0 &&
      before.os_tasks.task_desc_map(task) == Some(desc) &&
      desc.tdSchedMember.tsmStat == TSK_SUSPEND &&
      wakeup_msgqueue_send_head(mq, task, desc, before, after) &&
      msgqueue_send_pending_nodes(mq, after, rest) && os_inv(sg, after)
 */
/*@ msgqueue_recv_pending_head_ic <= wakeup_by_id_ic
    With (sg : StableGlobalState) (before : VarGlobalState)
      (mq task : Z) (rest : list(DL_Node Z))
    Require id < 65536 && get_task_with_idnode_success(sg, before, id, task) &&
      msgqueue_recv_pending_nodes(mq, before, cons(sched_link_node(task), rest)) &&
      os_inv(sg, before)
    Ensure exists (desc : TaskDescriptorAbs) (after : VarGlobalState),
      __return == 0 && task != 0 &&
      before.os_tasks.task_desc_map(task) == Some(desc) &&
      desc.tdSchedMember.tsmStat == TSK_SUSPEND &&
      wakeup_msgqueue_recv_head(mq, task, desc, before, after) &&
      msgqueue_recv_pending_nodes(mq, after, rest) && os_inv(sg, after)
 */
;

/* waiting 是调用前的挂起任务序列。正常返回时原等待任务均为 READY、
 * exstatus=-ERROR，等待链为空；整体效果还约束延时、就绪队列及其余状态变化。
 */
x_err_t LinklistResumeAll(DoubleLinklistType *list)
/*@ semaphore_waiters
    With (sg : StableGlobalState) (before : VarGlobalState)
         (sem : addr) (waiting : list addr)
    Require list == semaphore_pending_head(sem) &&
      semaphore_pending_nodes(sem, before, map(sched_link_node, waiting)) &&
      os_inv(sg, before)
    Ensure __return == KOK && exists after,
      semaphore_resume_all_effect(sem, waiting, before, after) &&
      semaphore_pending_nodes(sem, after, nil) && os_inv(sg, after)
 */
{
    x_ubase lock = 0;
    struct TaskDescriptor *task = NONE;
    DoubleLinklistType *node = NONE;

    if (list == NONE) {
        /*@ Inv Assert list == list@pre && list == 0 &&
            list == semaphore_pending_head(sem) &&
            semaphore_pending_nodes(sem, before, map(sched_link_node, waiting)) &&
            has_permission(&task) * has_permission(&node) * has_permission(&lock) *
            os_inv(sg, before)
         */ while (1) { } }

    /* Nested critical operation removed under the documented inside-critical adaptation. */
    /*@ Inv Assert exists (current : VarGlobalState) (remaining : list addr),
        list == list@pre && list != 0 && list == semaphore_pending_head(sem) &&
        semaphore_pending_nodes(sem, current, map(sched_link_node, remaining)) &&
        (forall (final : VarGlobalState),
          semaphore_resume_all_steps(sem, remaining, current, final) =>
          semaphore_resume_all_effect(sem, waiting, before, final)) &&
        has_permission(&task) * has_permission(&node) * has_permission(&lock) *
        os_inv(sg, current)
     */
    for(;;) {
        /*@ Given current remaining */
        /*@ semaphore_pending_nodes(sem, current, map(sched_link_node, remaining)) &&
            os_inv(sg, current)
            which implies exists next,
            semaphore_pending_nodes(sem, current, map(sched_link_node, remaining)) &&
            ((remaining == nil && next == list) ||
             (exists first tail, remaining == cons(first, tail) &&
               next == sched_link_of(first) && next != list)) &&
            (list->node_next == next) * resume_next_restore(sg, current, list, next)
         */
        /*@ Given next */
        node = list->node_next;
        /*@ (list->node_next == next) * resume_next_restore(sg, current, list, next)
            which implies os_inv(sg, current)
         */
        if(node != list) {
            /*@ node != list && node == next &&
                ((remaining == nil && next == list) ||
                 (exists first tail, remaining == cons(first, tail) &&
                   next == sched_link_of(first) && next != list)) &&
                semaphore_pending_nodes(sem, current, map(sched_link_node, remaining)) &&
                os_inv(sg, current)
                which implies exists target rest desc,
                remaining == cons(target, rest) && node == sched_link_of(target) &&
                target != 0 && addr_aligned(target, ALIGN_SIZE) &&
                current.os_tasks.task_desc_map(target) == Some(desc) &&
                desc.tdSchedMember.tsmStat == TSK_SUSPEND &&
                semaphore_pending_nodes(sem, current, cons(sched_link_node(target), map(sched_link_node, rest))) &&
                os_inv(sg, current)
             */
            /*@ Given target rest desc */
            task = CONTAINER_OF_TASK_SCHED(node) /*@ where task_ptr = target */;
            /*@ current.os_tasks.task_desc_map(task) == Some(desc) &&
                os_inv(sg, current)
                which implies exists marked,
                current.os_tasks.task_desc_map(task) == Some(desc) &&
                marked == replace_task_desc_map(
                  update_task_desc_map(task, set_task_desc_exstatus(desc, -1), current.os_tasks.task_desc_map), current) &&
                (task->exstatus == desc.tdExstatus) * resume_exstatus_restore(sg, marked, task, -1)
             */
            /*@ Given marked */
            task->exstatus = -ERROR;
            /*@ (task->exstatus == -1) * resume_exstatus_restore(sg, marked, task, -1)
                which implies os_inv(sg, marked)
             */
            /*@ remaining == cons(target, rest) && task == target &&
                semaphore_pending_nodes(sem, current, cons(sched_link_node(target), map(sched_link_node, rest))) &&
                marked == replace_task_desc_map(
                  update_task_desc_map(task, set_task_desc_exstatus(desc, -1), current.os_tasks.task_desc_map), current) &&
                os_inv(sg, marked)
                which implies exists task_id,
                remaining == cons(target, rest) && task == target &&
                semaphore_pending_nodes(sem, current, cons(sched_link_node(target), map(sched_link_node, rest))) &&
                marked == replace_task_desc_map(
                  update_task_desc_map(task, set_task_desc_exstatus(desc, -1), current.os_tasks.task_desc_map), current) &&
                0 <= task_id && task_id < 65536 &&
                get_task_with_idnode_success(sg, marked, task_id, task) &&
                semaphore_pending_nodes(sem, marked, cons(sched_link_node(task), map(sched_link_node, rest))) &&
                (task->id.id == task_id) * resume_id_restore(sg, marked, task, task_id)
             */
            /*@ Given task_id */
            int32 resume_task_id = task->id.id;
            /*@ (task->id.id == task_id) * resume_id_restore(sg, marked, task, task_id)
                which implies os_inv(sg, marked)
             */
            KTaskWakeup(resume_task_id) /*@ where (semaphore_pending_head_ic) sg = sg, before = marked, sem = sem, task = target, rest = map(sched_link_node, rest) */;
            /*@ Given woke_desc from desc */
            /*@ Given next_state from after */
        } else {
            break;
        }
    }
    

    return EOK;
}
